## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(JackiePackage)

## ----warning=FALSE------------------------------------------------------------
library(haven)
file_path <- system.file("Data", "completedata-4.sas7bdat", package = "JackiePackage")
data <- haven::read_sas(file_path)

## -----------------------------------------------------------------------------
selected_data <- data[, c("Age", "Sex", "Depression")]
fit_result <- Fit(selected_data, "Depression")

## -----------------------------------------------------------------------------
lm_result <- lm(Depression ~ Age + Sex, data = data)

## -----------------------------------------------------------------------------
jackie_coefs <- as.vector(fit_result$coefficients)
lm_coefs <- lm_result$coefficients
names(jackie_coefs) <- names(lm_coefs)
coeff_comparison <- all.equal(jackie_coefs, lm_coefs, tolerance = 1e-5)
print(paste("Coefficient equivalence: ", coeff_comparison))

## -----------------------------------------------------------------------------
library(bench)
efficiency_comparison <- bench::mark(
  Jackie = {
     Fit(selected_data, "Depression")
  },
  BaseR = {
    lm(Depression ~ Age + Sex, data = selected_data)
  },
  iterations = 100,
  check = FALSE 
)
print(efficiency_comparison)

## -----------------------------------------------------------------------------
Summary(fit_result)

## -----------------------------------------------------------------------------
summary(lm_result)
Summary(fit_result)

## -----------------------------------------------------------------------------
ANOVA(fit_result)

## -----------------------------------------------------------------------------
ANOVA(fit_result)
anova(lm_result)

## -----------------------------------------------------------------------------
# New data for prediction
new_data <- data.frame(
  Age = c(28, 36, 42),
  Sex = c(1, 0, 1)
)
# Predict using JackiePackage
jackie_predictions <- Predict(fit_result, new_data)
print("Predictions using JackiePackage:")
print(jackie_predictions)



## -----------------------------------------------------------------------------
# Predict using base R
lm_result <- lm(Depression ~ Age + Sex, data = data)
base_predictions <- predict(lm_result, newdata = new_data)
print("Predictions using Base R:")
print(base_predictions)

# Confirm equivalence of predictions
identical_predictions <- all.equal(as.vector(jackie_predictions), as.vector(base_predictions))
print(paste("Are predictions identical? ", identical_predictions))

